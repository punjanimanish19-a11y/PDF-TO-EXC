import { useCallback, useEffect, useRef, useState } from 'react';
import { ArrowDownToLine, ArrowRight, BadgeCheck, Check, ChevronRight, CircleHelp, CloudUpload, FileSpreadsheet, FileText, FileType2, FileWarning, LockKeyhole, RefreshCw, ShieldCheck, Sparkles, Table2, Upload, X, LoaderCircle } from 'lucide-react';

type Job = { id: string; status: string; stage: string; progress: number; original_filename: string; message: string; result?: { worksheet_count: number; extracted_tables: number; data_rows: number; warnings: string[]; worksheets: {name:string;rows:number;columns:number;has_header?:boolean}[] }; error?: string | null };
const API = (import.meta as any).env?.VITE_API_URL ?? 'http://localhost:8000';
const ACCEPT = '.pdf,.xlsx,.xls,.csv,.docx,.jpg,.jpeg,.png';
const DEFAULT_MAX_MB = 30;
const stages = ['Reading document', 'Extracting data', 'Understanding structure', 'Organizing worksheets', 'Formatting workbook', 'Validating Excel file', 'Preparing download'];
const formatBytes = (bytes: number) => bytes < 1024 * 1024 ? `${Math.max(1, Math.round(bytes / 1024))} KB` : `${(bytes / (1024 * 1024)).toFixed(1)} MB`;

export default function App() {
  const inputRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [job, setJob] = useState<Job | null>(null);
  const [busy, setBusy] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [error, setError] = useState('');
  const [maxMb, setMaxMb] = useState(DEFAULT_MAX_MB);

  useEffect(() => { fetch(`${API}/api/config`).then(r => r.ok ? r.json() : null).then(c => { if (c?.max_upload_mb) setMaxMb(c.max_upload_mb); }).catch(() => {}); }, []);

  const selectFile = (candidate?: File) => {
    if (!candidate) return;
    setError(''); setJob(null);
    const ext = `.${candidate.name.split('.').pop()?.toLowerCase()}`;
    if (!ACCEPT.split(',').includes(ext)) { setError('This file format is not supported. Choose a PDF, Excel, CSV, Word, or image file.'); return; }
    if (candidate.size > maxMb * 1024 * 1024) { setError(`This file is larger than the ${maxMb} MB upload limit.`); return; }
    if (candidate.size === 0) { setError('This file is empty. Choose a file containing data.'); return; }
    setFile(candidate);
  };

  const convert = async () => {
    if (!file || busy) return;
    setBusy(true); setError(''); setJob(null);
    try {
      const form = new FormData(); form.append('file', file);
      const response = await fetch(`${API}/api/jobs`, { method: 'POST', body: form });
      const body = await response.json();
      if (!response.ok) throw new Error(body.detail || 'Upload failed. Please try again.');
      setJob(body);
    } catch (e) { setError(e instanceof Error ? e.message : 'Could not connect to the conversion service.'); setBusy(false); }
  };

  const refreshJob = useCallback(async (id: string) => {
    try {
      const response = await fetch(`${API}/api/jobs/${id}`);
      const body = await response.json();
      if (!response.ok) throw new Error(body.detail || 'Could not retrieve job status.');
      setJob(body);
      if (body.status === 'completed' || body.status === 'failed') setBusy(false);
    } catch (e) { setError(e instanceof Error ? e.message : 'Could not refresh conversion status.'); setBusy(false); }
  }, []);

  useEffect(() => {
    if (!job?.id || job.status === 'completed' || job.status === 'failed') return;
    const timer = window.setInterval(() => refreshJob(job.id), 900);
    return () => window.clearInterval(timer);
  }, [job?.id, job?.status, refreshJob]);

  const reset = () => { setFile(null); setJob(null); setBusy(false); setError(''); if (inputRef.current) inputRef.current.value = ''; };
  const download = () => { if (job?.id) window.location.href = `${API}/api/jobs/${job.id}/download`; };
  const isDone = job?.status === 'completed';
  const isFailed = job?.status === 'failed';
  const isProcessing = !!job && !isDone && !isFailed;
  const activeStage = job ? Math.min(6, Math.max(0, Math.floor((job.progress / 100) * stages.length))) : 0;

  return <div className="app-shell">
    <header className="topbar">
      <a className="brand" href="#top" aria-label="AI Excel Pro home"><span className="brand-mark"><FileSpreadsheet size={21} strokeWidth={2.2}/><Sparkles size={11} className="brand-spark"/></span><span>AI Excel <b>Pro</b></span></a>
      <nav className="topnav"><a href="#how-it-works">How it works</a><a href="#features">Features</a><span className="privacy-pill"><LockKeyhole size={13}/> Privacy-first workflow</span></nav>
      <button className="header-upload" onClick={() => inputRef.current?.click()}><Upload size={15}/> Upload file</button>
    </header>

    <main id="top">
      <section className="hero">
        <div className="eyebrow"><span className="eyebrow-dot"/> YOUR SMARTER WORKFLOW STARTS HERE</div>
        <h1>Your documents in.<br/><span>Professional Excel out.</span></h1>
        <p className="hero-copy">Turn complex documents into clean, structured spreadsheets. Let AI organize the data while you focus on the work that matters.</p>
        <div className="hero-points"><span><Check size={15}/> Data-first formatting</span><span><Check size={15}/> Intelligent worksheets</span><span><Check size={15}/> Original values preserved</span></div>
      </section>

      <section className="workspace" aria-label="Document conversion">
        <div className="workspace-heading"><div><div className="section-kicker">DOCUMENT CONVERTER</div><h2>Start with your file</h2><p>Upload once. We’ll take care of the structure and formatting.</p></div><div className="secure-note"><ShieldCheck size={17}/><span>Your files stay private<br/><small>Processed securely by your server</small></span></div></div>

        {!job && <>
          <div className={`dropzone ${dragging ? 'dragging' : ''} ${file ? 'has-file' : ''}`} onDragOver={e => {e.preventDefault(); setDragging(true);}} onDragLeave={() => setDragging(false)} onDrop={e => {e.preventDefault(); setDragging(false); selectFile(e.dataTransfer.files?.[0]);}}>
            <input ref={inputRef} className="hidden-input" type="file" accept={ACCEPT} onChange={e => selectFile(e.target.files?.[0])}/>
            <div className="upload-illustration"><CloudUpload size={30}/><span className="upload-plus">+</span></div>
            {file ? <><h3>{file.name}</h3><p>{formatBytes(file.size)} · Ready to convert</p><div className="file-actions"><button className="text-button" onClick={e => {e.stopPropagation(); setFile(null); if (inputRef.current) inputRef.current.value='';}}>Remove file</button><button className="text-button" onClick={e => {e.stopPropagation(); inputRef.current?.click();}}>Choose another</button></div></> : <><h3>Drop your document here</h3><p>or <button className="inline-link" onClick={() => inputRef.current?.click()}>browse files</button> from your computer</p><div className="format-chips"><span><FileText size={13}/> PDF</span><span><FileSpreadsheet size={13}/> XLSX / XLS / CSV</span><span><FileType2 size={13}/> DOCX</span><span><FileWarning size={13}/> JPG / PNG</span></div><small className="limit-note">Maximum file size: {maxMb} MB</small></>}
          </div>
          {error && <div className="error-banner"><FileWarning size={17}/><span>{error}</span><button onClick={() => setError('')} aria-label="Dismiss error"><X size={16}/></button></div>}
          <button className="primary-button convert-button" disabled={!file} onClick={convert}><Sparkles size={17}/> Convert to Excel <ArrowRight size={17}/></button>
          <p className="under-button"><LockKeyhole size={12}/> Your document is only used to create your workbook.</p>
        </>}

        {isProcessing && <div className="processing-panel"><div className="processing-top"><div className="processing-icon"><LoaderCircle size={24}/></div><div><div className="processing-label">CONVERSION IN PROGRESS</div><h3>{job.stage}</h3><p>{job.message}</p></div><span className="progress-number">{job.progress}%</span></div><div className="progress-track"><div className="progress-value" style={{width:`${job.progress}%`}}/></div><div className="stage-list">{stages.map((s, i) => {const complete = job.progress >= Math.round(((i+1)/stages.length)*100); const active = !complete && i === activeStage; return <div className={`stage-row ${complete?'complete':''} ${active?'active':''}`} key={s}><span className="stage-check">{complete ? <Check size={13}/> : active ? <LoaderCircle size={13}/> : <span/>}</span><span>{s}</span>{active && <small>In progress</small>}</div>;})}</div><div className="processing-file"><FileSpreadsheet size={17}/><span>{job.original_filename}</span><span className="processing-badge">Processing</span></div></div>}

        {isFailed && <div className="result-panel failed-panel"><div className="result-icon failure"><FileWarning size={25}/></div><div className="result-label">CONVERSION NEEDS ATTENTION</div><h3>We couldn’t finish this file</h3><p>{job.error || job.message}</p><div className="result-actions"><button className="primary-button" onClick={reset}><RefreshCw size={16}/> Try another file</button><button className="secondary-button" onClick={() => {setJob(null); setBusy(false);}}>Retry conversion</button></div></div>}

        {isDone && job.result && <div className="result-panel"><div className="result-icon success"><BadgeCheck size={27}/></div><div className="result-label">WORKBOOK READY</div><h3>Your Excel file is ready.</h3><p>We’ve organized the extracted data and validated the generated workbook.</p><div className="result-file"><div className="result-file-icon"><FileSpreadsheet size={23}/></div><div className="result-file-info"><strong>{job.original_filename.replace(/\.[^.]+$/, '')}_Professional.xlsx</strong><span>{job.result.worksheet_count} worksheet{job.result.worksheet_count===1?'':'s'} · {job.result.data_rows.toLocaleString()} data rows</span></div><BadgeCheck className="result-file-check" size={20}/></div><div className="stats-grid"><div><span>Worksheets</span><strong>{job.result.worksheet_count}</strong></div><div><span>Tables detected</span><strong>{job.result.extracted_tables}</strong></div><div><span>Data rows</span><strong>{job.result.data_rows.toLocaleString()}</strong></div></div>{job.result.worksheets?.length>0 && <div className="sheet-list"><div className="sheet-list-heading"><Table2 size={15}/> WORKSHEET OVERVIEW</div>{job.result.worksheets.map(s=><div className="sheet-item" key={s.name}><span className="sheet-mini-icon"><Table2 size={14}/></span><strong>{s.name}</strong><span>{Math.max(0,s.rows-(s.has_header?1:0))} rows · {s.columns} columns</span><ChevronRight size={15}/></div>)}</div>}{job.result.warnings?.length>0 && <div className="warnings"><div><CircleHelp size={16}/> Review recommended</div><ul>{job.result.warnings.map((w,i)=><li key={i}>{w}</li>)}</ul></div>}<button className="primary-button download-button" onClick={download}><ArrowDownToLine size={18}/> Download Excel workbook</button><button className="process-another" onClick={reset}><RefreshCw size={14}/> Convert another document</button></div>}
      </section>

      <section className="benefit-strip" id="features"><div><span className="benefit-icon"><Table2 size={19}/></span><div><strong>Organized automatically</strong><p>Relevant data, in the right sheets.</p></div></div><div><span className="benefit-icon"><Sparkles size={19}/></span><div><strong>Business-ready formatting</strong><p>Readable columns, filters and headers.</p></div></div><div><span className="benefit-icon"><ShieldCheck size={19}/></span><div><strong>Careful with your data</strong><p>No intentional value guessing or rewriting.</p></div></div></section>

      <section className="how-section" id="how-it-works"><div className="section-kicker">SIMPLE BY DESIGN</div><h2>From document to spreadsheet in three steps</h2><div className="steps-grid"><div className="step-card"><span>01</span><div className="step-icon"><Upload size={20}/></div><h3>Upload</h3><p>Choose a PDF, spreadsheet, report, Word file, or image.</p></div><div className="step-card"><span>02</span><div className="step-icon"><Sparkles size={20}/></div><h3>Understand & organize</h3><p>The pipeline extracts content, structures worksheets, and checks the workbook.</p></div><div className="step-card"><span>03</span><div className="step-icon"><ArrowDownToLine size={20}/></div><h3>Download</h3><p>Get a formatted .xlsx file ready to use in Excel or compatible software.</p></div></div></section>
    </main>
    <footer><a className="brand footer-brand" href="#top"><span className="brand-mark"><FileSpreadsheet size={18}/></span><span>AI Excel <b>Pro</b></span></a><span>Thoughtful document conversion, without the busywork.</span><span className="footer-status"><span/> Conversion API workflow</span></footer>
  </div>;
}
