AI EXCEL PRO — WINDOWS EXE BUILD
================================

This package includes a Windows build script that creates AIExcelPro.exe.
The EXE must be built on a Windows PC; Windows executables cannot reliably be
compiled from this Linux build environment.

REQUIREMENTS
- Windows 10 or Windows 11, 64-bit
- Python 3.11 or 3.12 (enable “Add Python to PATH” during installation)
- Node.js 20 or newer (npm is included with Node.js)
- Internet connection for the first build to install dependencies

BUILD STEPS
1. Extract the entire ZIP into a normal folder, for example Desktop\AIExcelPro.
2. Install the requirements above if they are not already installed.
3. Double-click build_windows.bat.
4. Wait for dependency installation, frontend compilation, and packaging to finish.
5. The script creates AIExcelPro.exe in the project folder and in dist\.
6. Double-click AIExcelPro.exe. It starts the local app and opens your browser.

NOTES
- The first build can take several minutes and requires an internet connection.
- The EXE runs the web interface locally on this PC; it is not a hosted website.
- PDF and spreadsheet parsing are included. OCR for scanned documents requires the
  Tesseract OCR application installed separately on Windows and available on PATH.
- Optional AI structure planning requires server-side API credentials; the app can
  still use its deterministic fallback without them.
- Windows SmartScreen may warn about an unsigned EXE because it is locally built.
- Keep your original project folder: it contains the source and build script.
