from __future__ import annotations
import os, sys, uuid, shutil, threading, time
from pathlib import Path
from datetime import datetime, timezone
from typing import Any
from dotenv import load_dotenv
from fastapi import FastAPI, UploadFile, File, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from .processing import SUPPORTED, extract_document, generate_workbook

load_dotenv()
ROOT = Path(sys.executable).resolve().parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parents[1]
STORAGE = ROOT / 'runtime'
UPLOADS = STORAGE / 'uploads'
OUTPUTS = STORAGE / 'outputs'
for d in (UPLOADS, OUTPUTS): d.mkdir(parents=True, exist_ok=True)
MAX_MB = int(os.getenv('MAX_UPLOAD_MB', '30'))
JOBS: dict[str, dict[str, Any]] = {}
LOCK = threading.Lock()
app = FastAPI(title='AI Excel Pro API', version='1.0.0')
origins = [x.strip() for x in os.getenv('CORS_ORIGINS', 'http://localhost:5173').split(',') if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=False, allow_methods=['GET','POST','DELETE','OPTIONS'], allow_headers=['*'])

class JobResponse(BaseModel):
    id: str
    status: str
    stage: str
    progress: int
    original_filename: str
    message: str
    result: dict[str, Any] | None = None
    error: str | None = None
    created_at: str


def set_job(job_id: str, **kwargs):
    with LOCK:
        if job_id in JOBS: JOBS[job_id].update(kwargs)


def process_job(job_id: str, input_path: Path, output_path: Path):
    try:
        set_job(job_id, status='processing', stage='Inspecting document', progress=8, message='Checking file structure and choosing an extraction method.')
        # Extraction may take variable time, so progress changes at real pipeline boundaries.
        set_job(job_id, stage='Extracting content', progress=24, message='Reading text, tables, and values from the source document.')
        data = extract_document(input_path)
        set_job(job_id, stage='Understanding structure', progress=48, message='Identifying tables, headers, and meaningful sections.')
        set_job(job_id, stage='Organizing worksheets', progress=62, message='Planning compact worksheets while preserving the source values.')
        set_job(job_id, stage='Formatting workbook', progress=73, message='Applying consistent styles, widths, filters, and freeze panes.')
        result = generate_workbook(data, output_path)
        set_job(job_id, stage='Validating workbook', progress=91, message='Reopening the workbook and checking the generated sheets.')
        if not output_path.exists() or output_path.stat().st_size == 0:
            raise ValueError('The generated workbook could not be validated.')
        set_job(job_id, status='completed', stage='Ready to download', progress=100, message='Your Excel workbook has been generated and validated.', result=result)
    except Exception as exc:
        set_job(job_id, status='failed', stage='Could not complete conversion', progress=100,
                message='The document could not be converted safely.', error=str(exc)[:500])
    finally:
        try: input_path.unlink(missing_ok=True)
        except Exception: pass

@app.get('/api/health')
def health():
    return {'status':'ok', 'service':'AI Excel Pro API'}

@app.get('/api/config')
def public_config():
    # Only expose non-sensitive settings needed to guide uploads in the browser.
    return {'max_upload_mb': MAX_MB, 'supported_extensions': sorted(SUPPORTED)}

@app.post('/api/jobs', response_model=JobResponse)
async def create_job(background_tasks: BackgroundTasks, file: UploadFile = File(...)):
    filename = Path(file.filename or 'upload').name
    ext = Path(filename).suffix.lower()
    if ext not in SUPPORTED:
        raise HTTPException(415, f'Unsupported file format. Supported formats: {", ".join(sorted(SUPPORTED))}.')
    job_id = uuid.uuid4().hex
    input_path = UPLOADS / f'{job_id}{ext}'
    output_path = OUTPUTS / f'{job_id}.xlsx'
    size = 0
    try:
        with input_path.open('wb') as out:
            while True:
                chunk = await file.read(1024 * 1024)
                if not chunk: break
                size += len(chunk)
                if size > MAX_MB * 1024 * 1024:
                    out.close(); input_path.unlink(missing_ok=True)
                    raise HTTPException(413, f'File exceeds the configured {MAX_MB} MB upload limit.')
                out.write(chunk)
    finally:
        await file.close()
    if size == 0:
        input_path.unlink(missing_ok=True)
        raise HTTPException(400, 'The uploaded file is empty.')
    # Basic signature validation prevents a mismatched extension from reaching parsers.
    head = input_path.read_bytes()[:16]
    signatures = {'.pdf': b'%PDF', '.xlsx': b'PK', '.docx': b'PK', '.png': b'\x89PNG\r\n\x1a\n', '.jpg': b'\xff\xd8\xff', '.jpeg': b'\xff\xd8\xff'}
    if ext in signatures and not head.startswith(signatures[ext]):
        input_path.unlink(missing_ok=True)
        raise HTTPException(400, 'The file content does not match its extension, or the file is damaged.')
    job = {'id':job_id, 'status':'queued', 'stage':'Upload received', 'progress':2, 'original_filename':filename,
           'message':'Upload complete. Preparing document analysis.', 'result':None, 'error':None,
           'created_at':datetime.now(timezone.utc).isoformat(), 'output_path':str(output_path)}
    with LOCK: JOBS[job_id] = job
    background_tasks.add_task(process_job, job_id, input_path, output_path)
    return JobResponse(**{k:v for k,v in job.items() if k != 'output_path'})

@app.get('/api/jobs/{job_id}', response_model=JobResponse)
def get_job(job_id: str):
    with LOCK: job = JOBS.get(job_id, {}).copy()
    if not job: raise HTTPException(404, 'Processing job not found or expired.')
    job.pop('output_path', None)
    return JobResponse(**job)

@app.get('/api/jobs/{job_id}/download')
def download_job(job_id: str):
    with LOCK: job = JOBS.get(job_id, {}).copy()
    if not job: raise HTTPException(404, 'Processing job not found or expired.')
    if job.get('status') != 'completed': raise HTTPException(409, 'The workbook is not ready to download yet.')
    path = Path(job['output_path'])
    if not path.exists(): raise HTTPException(410, 'This download has expired. Please upload the document again.')
    stem = Path(job['original_filename']).stem
    safe_stem = ''.join(c if c.isalnum() or c in '-_ ' else '_' for c in stem).strip().replace(' ', '_')[:90] or 'Document'
    return FileResponse(path, media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                        filename=f'{safe_stem}_Professional.xlsx')

@app.delete('/api/jobs/{job_id}')
def delete_job(job_id: str):
    with LOCK: job = JOBS.pop(job_id, None)
    if not job: raise HTTPException(404, 'Processing job not found or expired.')
    for key in ('output_path',):
        if job.get(key): Path(job[key]).unlink(missing_ok=True)
    return {'deleted':True}


# Serve the compiled web interface when running as a desktop application.
_WEB_DIR = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent)) / 'app' / 'web'
if _WEB_DIR.exists():
    app.mount('/', StaticFiles(directory=str(_WEB_DIR), html=True), name='web')
