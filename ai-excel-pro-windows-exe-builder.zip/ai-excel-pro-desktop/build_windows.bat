@echo off
setlocal
cd /d "%~dp0"
echo ======================================================
echo       AI Excel Pro - Windows EXE Builder
echo ======================================================
where py >nul 2>nul
if errorlevel 1 (
  echo ERROR: Python 3.11 or 3.12 is required. Install it from https://www.python.org/downloads/windows/
  echo Make sure you enable "Add Python to PATH" during installation.
  pause
  exit /b 1
)
where npm >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js 20 or newer is required. Install it from https://nodejs.org/
  pause
  exit /b 1
)
if not exist .build-venv (
  py -3 -m venv .build-venv
  if errorlevel 1 goto failed
)
call .build-venv\Scripts\activate.bat
python -m pip install --upgrade pip
if errorlevel 1 goto failed
pip install -r backend\requirements.txt pyinstaller
if errorlevel 1 goto failed
pushd frontend
call npm install
if errorlevel 1 (popd & goto failed)
set VITE_API_URL=
call npm run build
if errorlevel 1 (popd & goto failed)
popd
if exist backend\app\web rmdir /s /q backend\app\web
mkdir backend\app\web
xcopy frontend\dist backend\app\web /E /I /Y >nul
if errorlevel 1 goto failed
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
pyinstaller --noconfirm --clean --name AIExcelPro --onefile --windowed --paths backend --add-data "backend\app\web;app\web" --collect-all pdfplumber --collect-all fitz --collect-all openpyxl --collect-all pandas --collect-all PIL --collect-all pytesseract --hidden-import app.processing --hidden-import app.main --hidden-import multipart backend\app\desktop.py
if errorlevel 1 goto failed
if not exist dist\AIExcelPro.exe goto failed
copy /Y dist\AIExcelPro.exe AIExcelPro.exe >nul
echo.
echo SUCCESS! Your EXE is ready:
echo %CD%\AIExcelPro.exe
echo.
echo Double-click AIExcelPro.exe to open AI Excel Pro in your browser.
echo For scanned PDFs/images, install Tesseract OCR separately if OCR is needed.
pause
exit /b 0
:failed
echo.
echo BUILD FAILED. Read the error above, then check README-WINDOWS-EXE.txt.
pause
exit /b 1
