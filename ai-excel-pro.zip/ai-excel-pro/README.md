# AI Excel Pro

A full-stack document-to-Excel conversion application built around conservative extraction, structured workbook planning, professional formatting, and validation.

## Features
- Drag-and-drop uploads with file and size validation
- FastAPI backend with real job status and stage updates
- PDF, XLSX, XLS, CSV, DOCX, JPG/JPEG, and PNG parsers where dependencies are available
- PDF table extraction with text/OCR fallback
- Automatic worksheet planning for distinct tables and metadata
- Conservative cleaning: no invented values, no silent amount changes, identifiers retained as text
- Professional navy headers, filters, freeze panes, adaptive widths, and compact contiguous tables
- Reopens and validates generated workbooks before enabling download
- Optional OpenAI-compatible model integration for structure planning (configured server-side)

## Run locally

### Requirements
- Python 3.10+
- Node.js 18+
- For OCR on scanned PDFs/images: install Tesseract OCR on the host and ensure `tesseract` is on PATH.

### Backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload --port 8000
```

### Frontend
In a second terminal:
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:5173. The frontend expects the API at http://localhost:8000; set `VITE_API_URL` if needed.

## Environment variables
See `backend/.env.example`. AI planning is optional. Without credentials, deterministic heuristics are used. The application never exposes API credentials to the browser.

## Important deployment notes
- Configure `MAX_UPLOAD_MB`, rate limiting, HTTPS, private object storage, and retention cleanup for production.
- The starter uses in-memory job metadata and local temporary storage; use Redis/database + a worker queue for multi-instance deployments.
- OCR requires a host-installed Tesseract binary. Unsupported parser dependencies produce clear errors rather than fake success.
- Progress updates reflect actual processing stages, not timer-based percentages.

## Tests
```bash
cd backend
pytest
```
