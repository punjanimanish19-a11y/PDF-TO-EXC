from __future__ import annotations
import csv, io, json, os, re, shutil, subprocess, tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.utils import get_column_letter

SUPPORTED = {'.pdf', '.xlsx', '.xls', '.csv', '.docx', '.jpg', '.jpeg', '.png'}

@dataclass
class SheetData:
    name: str
    rows: list[list[Any]]
    header_row: bool = True
    source: str = ''

@dataclass
class DocumentData:
    metadata: list[list[Any]] = field(default_factory=list)
    sheets: list[SheetData] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    extracted_tables: int = 0


def clean_cell(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, str):
        value = value.replace('\x00', '').strip()
        return value if value else None
    return value


def remove_empty_edges(rows: list[list[Any]]) -> list[list[Any]]:
    """Remove fully empty rows/columns only; preserve empty cells inside valid records."""
    rows = [[clean_cell(v) for v in row] for row in rows]
    rows = [r for r in rows if any(v is not None for v in r)]
    if not rows:
        return []
    width = max(len(r) for r in rows)
    rows = [r + [None] * (width - len(r)) for r in rows]
    keep_cols = [i for i in range(width) if any(r[i] is not None for r in rows)]
    return [[r[i] for i in keep_cols] for r in rows]


def unique_headers(row: list[Any]) -> list[str]:
    seen: dict[str, int] = {}
    result = []
    for i, item in enumerate(row):
        name = str(item).strip() if item is not None else f'Column {i + 1}'
        if not name:
            name = f'Column {i + 1}'
        seen[name] = seen.get(name, 0) + 1
        if seen[name] > 1:
            name = f'{name} ({seen[name]})'
        result.append(name[:255])
    return result


def safe_sheet_name(name: str, used: set[str]) -> str:
    name = re.sub(r'[\\/*?:\[\]]', ' ', name).strip().strip("'") or 'Data'
    name = name[:31]
    candidate, n = name, 2
    while candidate.lower() in used:
        suffix = f' {n}'
        candidate = name[:31-len(suffix)] + suffix
        n += 1
    used.add(candidate.lower())
    return candidate


def parse_pdf(path: Path, data: DocumentData) -> None:
    import pdfplumber
    extracted = []
    page_texts = []
    with pdfplumber.open(path) as pdf:
        for pageno, page in enumerate(pdf.pages, start=1):
            text = page.extract_text() or ''
            page_texts.append((pageno, text))
            try:
                tables = page.extract_tables()
            except Exception:
                tables = []
            for table in tables or []:
                cleaned = remove_empty_edges(table)
                if cleaned and len(cleaned) >= 2 and max((len(r) for r in cleaned), default=0) >= 2:
                    extracted.append((pageno, cleaned))
    # Merge tables with matching headers across pages; repeated page headers are not records.
    grouped: list[tuple[str, list[list[Any]], int]] = []
    for pageno, rows in extracted:
        header = tuple(str(v or '').strip().lower() for v in rows[0])
        match = next((g for g in grouped if tuple(str(v or '').strip().lower() for v in g[1][0]) == header), None)
        if match:
            for row in rows[1:]:
                if [str(x or '').strip() for x in row] != [str(x or '').strip() for x in rows[0]]:
                    match[1].append(row)
        else:
            grouped.append((f'Table {len(grouped)+1}', rows, pageno))
    for name, rows, pageno in grouped:
        data.sheets.append(SheetData(name, rows, True, f'PDF page {pageno}'))
    data.extracted_tables = len(grouped)
    all_text = '\n'.join(t for _, t in page_texts).strip()
    if not grouped:
        # OCR fallback only if digital text extraction found little content.
        if len(all_text) < 40:
            try:
                import fitz, pytesseract
                from PIL import Image
                doc = fitz.open(path)
                for pageno, page in enumerate(doc, start=1):
                    pix = page.get_pixmap(matrix=fitz.Matrix(2, 2), alpha=False)
                    img = Image.open(io.BytesIO(pix.tobytes('png')))
                    ocr = pytesseract.image_to_string(img)
                    lines = [re.split(r'\s{2,}|\t+', x.strip()) for x in ocr.splitlines() if x.strip()]
                    lines = remove_empty_edges(lines)
                    if lines:
                        data.sheets.append(SheetData(f'Page {pageno}', lines, False, f'OCR page {pageno}'))
                if data.sheets:
                    data.warnings.append('OCR fallback was used. Review extracted text and columns for recognition errors.')
            except Exception as exc:
                data.warnings.append(f'No reliable PDF tables were detected. OCR fallback was unavailable: {type(exc).__name__}.')
        else:
            # Preserve text lines as rows rather than fabricating table structure.
            lines = [[line.strip()] for _, text in page_texts for line in text.splitlines() if line.strip()]
            if lines:
                data.sheets.append(SheetData('Extracted Text', lines, False, 'PDF text'))
                data.warnings.append('No structured tables were detected; PDF text was preserved as a single-column worksheet.')
    if not data.sheets:
        raise ValueError('No readable text or tables were found in this PDF.')


def parse_xlsx(path: Path, data: DocumentData) -> None:
    wb = load_workbook(path, data_only=False, read_only=True)
    for ws in wb.worksheets:
        rows = remove_empty_edges([list(row) for row in ws.iter_rows(values_only=True)])
        if rows:
            data.sheets.append(SheetData(ws.title, rows, True, f'Worksheet {ws.title}'))
    data.extracted_tables = len(data.sheets)
    if not data.sheets:
        raise ValueError('The workbook does not contain any populated worksheets.')


def parse_csv(path: Path, data: DocumentData) -> None:
    raw = path.read_text(encoding='utf-8-sig', errors='replace')
    try:
        dialect = csv.Sniffer().sniff(raw[:8192], delimiters=',;\t|')
    except csv.Error:
        dialect = csv.excel
    rows = remove_empty_edges(list(csv.reader(io.StringIO(raw), dialect)))
    if not rows:
        raise ValueError('The CSV file is empty.')
    data.sheets.append(SheetData('Data', rows, True, 'CSV'))
    data.extracted_tables = 1


def parse_docx(path: Path, data: DocumentData) -> None:
    from docx import Document
    doc = Document(path)
    for i, table in enumerate(doc.tables, start=1):
        rows = remove_empty_edges([[cell.text.strip() for cell in row.cells] for row in table.rows])
        if rows:
            data.sheets.append(SheetData(f'Table {i}', rows, True, f'DOCX table {i}'))
    paragraphs = [[p.text.strip()] for p in doc.paragraphs if p.text.strip()]
    if paragraphs:
        data.sheets.insert(0, SheetData('Document Text', paragraphs, False, 'DOCX paragraphs'))
    data.extracted_tables = len(doc.tables)
    if not data.sheets:
        raise ValueError('No readable paragraphs or tables were found in this DOCX file.')


def parse_image(path: Path, data: DocumentData) -> None:
    try:
        from PIL import Image
        import pytesseract
        image = Image.open(path)
        text = pytesseract.image_to_string(image)
    except Exception as exc:
        raise ValueError('Image OCR requires Pillow, pytesseract, and the Tesseract OCR application installed on the server.') from exc
    lines = [re.split(r'\s{2,}|\t+', line.strip()) for line in text.splitlines() if line.strip()]
    rows = remove_empty_edges(lines)
    if not rows:
        raise ValueError('No readable text was detected in this image.')
    data.sheets.append(SheetData('Extracted Data', rows, False, 'Image OCR'))
    data.extracted_tables = 1
    data.warnings.append('OCR was used for this image. Verify masked values, dates, and numeric amounts against the source.')


def parse_xls(path: Path, data: DocumentData) -> None:
    try:
        import pandas as pd
        book = pd.ExcelFile(path)
        for sheet in book.sheet_names:
            frame = pd.read_excel(path, sheet_name=sheet, header=None, dtype=object)
            rows = remove_empty_edges(frame.where(frame.notna(), None).values.tolist())
            if rows:
                data.sheets.append(SheetData(sheet, rows, True, f'Worksheet {sheet}'))
        data.extracted_tables = len(data.sheets)
    except Exception as exc:
        raise ValueError('Could not read this XLS file. Install a compatible legacy Excel reader (xlrd) on the server.') from exc
    if not data.sheets:
        raise ValueError('The XLS file has no populated worksheets.')


def extract_document(path: Path) -> DocumentData:
    data = DocumentData()
    ext = path.suffix.lower()
    if ext == '.pdf': parse_pdf(path, data)
    elif ext == '.xlsx': parse_xlsx(path, data)
    elif ext == '.xls': parse_xls(path, data)
    elif ext == '.csv': parse_csv(path, data)
    elif ext == '.docx': parse_docx(path, data)
    elif ext in {'.jpg', '.jpeg', '.png'}: parse_image(path, data)
    else: raise ValueError(f'Unsupported file type: {ext}')
    # Add compact file metadata for traceability, not as decorative blank rows.
    data.metadata = [['Source filename', path.name], ['Source format', ext.lstrip('.').upper()]]
    return data


def infer_headers(rows: list[list[Any]]) -> tuple[list[list[Any]], bool]:
    rows = remove_empty_edges(rows)
    if not rows:
        return [], False
    first = rows[0]
    # Treat row as header if most populated values are text and subsequent rows contain data.
    populated = [x for x in first if x is not None]
    text_count = sum(isinstance(x, str) and not re.fullmatch(r'[-+]?\d+(\.\d+)?', x.strip()) for x in populated)
    header = bool(len(rows) > 1 and populated and text_count >= max(1, len(populated) * 0.5))
    if header:
        rows[0] = unique_headers(first)
    return rows, header


def apply_optional_ai_plan(data: DocumentData) -> None:
    """Optional semantic naming/planning via an OpenAI-compatible API; safe heuristic fallback."""
    base_url = os.getenv('AI_BASE_URL', '').strip().rstrip('/')
    api_key, model = os.getenv('AI_API_KEY', '').strip(), os.getenv('AI_MODEL', '').strip()
    if not (base_url and api_key and model):
        return
    try:
        import httpx
        sample = [{'name': s.name, 'rows': s.rows[:4]} for s in data.sheets[:8]]
        prompt = ('You are planning Excel worksheet names for extracted document data. Do not change, invent, or remove cell values. '
                  'Return only JSON: {"names":[{"index":0,"name":"Transactions"}]}. '
                  'Choose concise descriptive names grounded in the sample. Samples: ' + json.dumps(sample, ensure_ascii=False, default=str)[:12000])
        r = httpx.post(f'{base_url}/chat/completions', headers={'Authorization': f'Bearer {api_key}'},
                       json={'model': model, 'messages': [{'role':'user','content':prompt}], 'temperature':0}, timeout=20)
        r.raise_for_status()
        result = json.loads(r.json()['choices'][0]['message']['content'])
        for item in result.get('names', []):
            idx, name = item.get('index'), item.get('name')
            if isinstance(idx, int) and 0 <= idx < len(data.sheets) and isinstance(name, str) and name.strip():
                data.sheets[idx].name = name.strip()[:31]
    except Exception:
        data.warnings.append('Optional AI worksheet naming was unavailable; deterministic naming was used instead.')


def generate_workbook(data: DocumentData, output_path: Path) -> dict[str, Any]:
    apply_optional_ai_plan(data)
    wb = Workbook()
    wb.remove(wb.active)
    used: set[str] = set()
    navy = '17365D'; white = 'FFFFFF'; light_blue = 'EAF1F8'; border_color = 'D8E0EA'
    thin = Side(style='thin', color=border_color)
    total_rows = 0
    sheet_summaries = []
    for s in data.sheets:
        rows, has_header = infer_headers(s.rows)
        if not rows:
            continue
        name = safe_sheet_name(s.name, used)
        ws = wb.create_sheet(name)
        for r_idx, row in enumerate(rows, start=1):
            for c_idx, value in enumerate(row, start=1):
                # Keep masked values and identifiers as strings; never coerce identifier-looking fields.
                cell = ws.cell(r_idx, c_idx, value=value)
                cell.alignment = Alignment(vertical='center', wrap_text=False)
                cell.border = Border(bottom=thin)
                if r_idx == 1 and has_header:
                    cell.fill = PatternFill('solid', fgColor=navy)
                    cell.font = Font(name='Aptos', size=10, bold=True, color=white)
                    cell.alignment = Alignment(vertical='center', horizontal='left', wrap_text=True)
                else:
                    cell.font = Font(name='Aptos', size=10, color='243247')
                    if r_idx % 2 == 0:
                        cell.fill = PatternFill('solid', fgColor=light_blue)
                    if isinstance(value, str) and re.search(r'(^0\d+$|X{2,}|@|[A-Za-z].*\d|\d.*[A-Za-z])', value):
                        cell.number_format = '@'
                    elif isinstance(value, (int, float)) and not isinstance(value, bool):
                        cell.number_format = '#,##0.00;[Red]-#,##0.00;0'
            ws.row_dimensions[r_idx].height = 22 if r_idx == 1 and has_header else 19
        # Keep the exported region contiguous; no spacer rows or columns are inserted.
        max_row, max_col = ws.max_row, ws.max_column
        if has_header and max_row >= 2 and max_col >= 1:
            ref = f'A1:{get_column_letter(max_col)}{max_row}'
            tab_name = re.sub(r'\W', '', name)[:20] or 'Data'
            existing = {t.displayName for t in ws.tables.values()}
            k, base = 2, tab_name
            while tab_name in existing:
                tab_name = f'{base}{k}'; k += 1
            tab = Table(displayName=tab_name, ref=ref)
            tab.tableStyleInfo = TableStyleInfo(name='TableStyleMedium2', showFirstColumn=False, showLastColumn=False,
                                                showRowStripes=False, showColumnStripes=False)
            try: ws.add_table(tab)
            except Exception:
                ws.auto_filter.ref = ref
            ws.freeze_panes = 'A2'
        elif has_header and max_row == 1:
            ws.freeze_panes = 'A2'
            ws.auto_filter.ref = f'A1:{get_column_letter(max_col)}1'
        # Widths based on representative data, with a cap to avoid one long value making a sheet unusable.
        for col_idx in range(1, max_col + 1):
            vals = [ws.cell(r, col_idx).value for r in range(1, min(max_row, 100) + 1)]
            longest = max((len(str(v)) for v in vals if v is not None), default=8)
            header_len = len(str(ws.cell(1, col_idx).value or ''))
            width = min(42, max(10, min(max(longest, header_len) + 2, 42)))
            ws.column_dimensions[get_column_letter(col_idx)].width = width
            if longest > 38:
                for r in range(1, max_row + 1):
                    ws.cell(r, col_idx).alignment = Alignment(vertical='center', wrap_text=True)
        ws.sheet_view.showGridLines = False
        ws.freeze_panes = ws.freeze_panes or 'A1'
        ws.sheet_properties.pageSetUpPr.fitToPage = True
        ws.page_setup.fitToWidth = 1
        ws.page_setup.fitToHeight = 0
        ws.page_margins.left = 0.25; ws.page_margins.right = 0.25
        total_rows += max(0, max_row - (1 if has_header else 0))
        sheet_summaries.append({'name': name, 'rows': max_row, 'columns': max_col, 'has_header': has_header})
    if not wb.sheetnames:
        raise ValueError('No non-empty worksheets could be generated.')
    wb.save(output_path)
    # Reopen and verify the workbook before delivery.
    check = load_workbook(output_path, read_only=False, data_only=False)
    if not check.sheetnames or output_path.stat().st_size == 0:
        raise ValueError('Workbook validation failed: output file is empty or unreadable.')
    for ws in check.worksheets:
        if ws.max_row < 1 or ws.max_column < 1:
            raise ValueError(f'Workbook validation failed for worksheet {ws.title}.')
    check.close()
    return {'worksheets': sheet_summaries, 'worksheet_count': len(sheet_summaries),
            'extracted_tables': data.extracted_tables, 'data_rows': total_rows,
            'warnings': data.warnings, 'size_bytes': output_path.stat().st_size}
