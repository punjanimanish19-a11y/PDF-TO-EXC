from pathlib import Path
from openpyxl import load_workbook
from app.processing import remove_empty_edges, safe_sheet_name, SheetData, DocumentData, generate_workbook


def test_remove_empty_edges_keeps_internal_empty_cells():
    assert remove_empty_edges([[None, 'A', None], [None, 1, None], [None, None, None]]) == [['A'], [1]]
    assert remove_empty_edges([['id', 'name', 'amount'], ['001', None, 10]]) == [['id', 'name', 'amount'], ['001', None, 10]]


def test_sheet_names_are_safe_and_unique():
    used = set()
    assert safe_sheet_name('Bad/Name', used) == 'Bad Name'
    assert safe_sheet_name('Bad/Name', used) == 'Bad Name 2'
    assert len(safe_sheet_name('x' * 50, used)) <= 31


def test_workbook_generation_is_readable_and_compact(tmp_path):
    data = DocumentData(sheets=[SheetData('Transactions', [['ID', 'Amount'], ['001', 20], ['002', -2]])], extracted_tables=1)
    output = tmp_path / 'out.xlsx'
    result = generate_workbook(data, output)
    wb = load_workbook(output, data_only=False)
    ws = wb['Transactions']
    assert result['worksheet_count'] == 1
    assert ws.max_row == 3 and ws.max_column == 2
    assert ws['A2'].value == '001'
    assert ws.freeze_panes == 'A2'
    assert ws.auto_filter.ref or len(ws.tables) == 1
